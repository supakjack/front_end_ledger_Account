<template>
  <q-page padding>
    <!-- content -->
    <div class="q-pa-md q-gutter-sm">
      <q-banner class="bg-grey-3">
        <p style="text-align:left;"></p>
        <div>วันนี้</div>
        <div>19 กุมภาพันธ์ 2020</div>
        <span style="float:right;">
          <button style="border:1px solid transparent; background-color: transparent;">
            <i class="material-icons" style="font-size:40px">keyboard_arrow_right</i>
          </button>
        </span>
      </q-banner>
      <q-banner class="bg-red-3">
        <p style="text-align:left;">
          <i class="material-icons" style="color:red">
            <div style="font-size:25px">local_grocery_store</div>
          </i>รายจ่าย
          <span style="float:right;">
            <p align="right">100.00 บาท</p>
          </span>
        </p>
      </q-banner>
      <q-banner class="bg-green-3">
        <p style="text-align:left;">
          <i class="material-icons" style="color:green">
            <div style="font-size:25px">local_atm</div>
          </i>รายรับ
          <span style="float:right;">
            <p align="right">1000.50 บาท</p>
          </span>
        </p>
      </q-banner>
    </div>
    <div class="q-pa-md q-gutter-sm">
      <div align="center">
        <q-btn size="12px" class="q-px-xl q-py-xs" color="red" label="รายจ่าย" />
        <q-btn size="12px" class="q-px-xl q-py-xs" color="green" label="รายรับ" />
      </div>
    </div>

    <div class="q-pa-md">
      <div class="column" style="height: 150px">
        <div class="col">
          <center>
            <b style="font-size:25px; text-align:center;">ยอดรวมเงินทั้งหมด</b>
          </center>
        </div>
        <div class="col">
          <center>
            <b style="font-size:18px; text-align:center;">{{total}} บาท</b>
          </center>
        </div>
      </div>
      <center>
        <canvas id="myChart" height="100vh" width="130vw"></canvas>
      </center>

      <div class="row" style="font-size:20px;">
        <div class="col" style="color:red; text-align:center;">
          <b>รายจ่าย</b>
        </div>
        <div class="col" style="color:blue; text-align:center;">
          <b>รายรับ</b>
        </div>
      </div>

      <div class="row" style="font-size:15px;">
        <div class="col" style="color:red; text-align:center;">{{expense}} บาท</div>
        <div class="col" style="color:blue; text-align:center;">{{Income}} บาท</div>
      </div>
    </div>
  </q-page>
</template>

<script>
import AxiosServices from "./../services/AxiosServices";
import ChartServices from "./../services/ChartServices";
import SwalServices from "./../services/SwalServices";

export default {
  name: "Home",
  async mounted() {
    // new SwalServices().makeAlert().fire({
    //   title: "Error!",
    //   text: "Do you want to continue",
    //   icon: "error",
    //   confirmButtonText: "Cool"
    // });

    const { value: password } = await new SwalServices().makeAlert().fire({
      title: "Enter your password",
      input: "password",
      inputPlaceholder: "Enter your password",
      inputAttributes: {
        maxlength: 10,
        autocapitalize: "off",
        autocorrect: "off"
      }
    });

    if (password) {
      new SwalServices().makeAlert().fire(`Entered password: ${password}`);
      this.changeToatl(password)
    }

    // new SwalServices().makeAlert().fire({
    //   title: "<strong>HTML <u>example</u></strong>",
    //   icon: "info",
    //   html:
    //     '<div class="q-pa-md">' +
    //     '<div class="q-gutter-md" style="max-width: 300px">' +
    //     '<q-input v-model="text" label="Standard" />' +
    //     '<q-input filled v-model="text" label="Filled" />' +
    //     "</div>" +
    //     "</div>",
    //   showCloseButton: true,
    //   showCancelButton: true,
    //   focusConfirm: false,
    //   confirmButtonText: '<i class="fa fa-thumbs-up"></i> Great!',
    //   confirmButtonAriaLabel: "Thumbs up, great!",
    //   cancelButtonText: '<i class="fa fa-thumbs-down"></i>',
    //   cancelButtonAriaLabel: "Thumbs down"
    // });

    console.log(new AxiosServices().getHttp("books/1"));
    new ChartServices().makeChart(
      "myChart",
      "doughnut",
      {
        labels: ["รายจ่าย", "รายรับ"],
        datasets: [
          {
            label: "# of Votes",
            data: [100, 1000.5],
            backgroundColor: [
              "rgba(255, 99, 132, 0.2)",
              "rgba(54, 162, 235, 0.2)"
            ],
            borderColor: ["rgba(255, 99, 132, 1)", "rgba(54, 162, 235, 1)"],
            borderWidth: 1
          }
        ]
      },
      {
        scales: {
          yAxes: [
            {
              ticks: {
                beginAtZero: true,
                display: false
              }
            }
          ]
        }
      }
    );
  },
  data() {
    return {
      total: "1000.50",
      expense: "100.00",
      Income: "1000.50",
      value: 10,
      text: "555"
    };
  },
  methods: {
    changeToatl(money){
      this.total = money;
    }
  },
};
</script>