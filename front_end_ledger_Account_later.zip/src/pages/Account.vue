<template>
  <q-page class="bg-grey-3 column">
    <q-list class="bg-white" separator bordered>
      <!-- <div class="row q-pa-sm bg-primary">
        <q-input
          @keyup.enter="addTask"
          class="col"
          square
          filled
          v-model="newTask"
          placeholder="เพิ่มรายการ"
          bg-color="white"
          dense
        >
          <template v-slot:append>
            <q-btn @click="addTask" round dense flat icon="add" />
          </template>
        </q-input>
      </div> -->

      <q-item
        clickable
        @click="task.done!=task.done"
        v-for="(task,index) in tasks"
        :key="index"
        tag="label"
        v-ripple
        :class="{'done bg-blue-1':task.done}"
      >
        <q-item-section avatar>
          <q-checkbox class="no-pointer-events" v-model="task.done" val="teal" color="teal" />
        </q-item-section>
        <q-item-section>
          <q-item-label>{{task.title}}</q-item-label>
        </q-item-section>
        <q-item-section v-if="task.done">
          <q-btn @click.stop="deleteTask(index)" flat round color="primary" icon="card_giftcard" />
        </q-item-section>
      </q-item>
    </q-list>
     
    


<div class="q-pa-md" style="width: 100%">
    <q-toggle v-model="expanded" label="Expanded" class="q-mb-md" />
    
    <q-expansion-item
      v-model="expanded"
      icon="monetization_on"
      label="เงินสด"
      caption="1500.00 บาท"
    >
      <q-card>
        <q-card-section>

           <q-item-section >
            รายละเอียดบัญชี
          </q-item-section>
<br>
  <q-input
        filled
        v-model="name"
        label="Your name *"
      />
<br>
  <q-input
        filled
        type="number"
        v-model="money"
        label="Your Money"
      />

<br>
<br>

      <q-item-section >
            ประเภทบัญชี เงินสด
          </q-item-section>
<br>
  <q-input
        filled
        type="number"
        v-model="Total_money"
        label="Total Money"
      />

<br>



        </q-card-section>
        <div  class="q-pa-md" style="max-width: 1500px">    
          <q-btn color="primary" label="บันทึก" style="width: 100%" />
        </div>

        <div  class="q-pa-md" style="max-width: 1500px">    
          <q-btn color="red" label="ยกเลิก" style="width: 100%" />
        </div>



        
      </q-card>
    </q-expansion-item>
  </div>


  <!-- end tab 1  -->


<br>
<br>
        <div class="q-pa-md q-gutter-sm " style="max-width: 1500px">
            <q-btn label="เพิ่มบัญชี" color="primary" style="width: 100%" @click="prompt" />
      </div>



  </q-page>
</template>


<script>

export default {
  name:"wxdwxwd",
  data() {
    return {
      money:'',
      Total_money:'',
      name:"สุพัดชัย",
      expanded: false,
      newTask: "",
      tasks: [
        // { title: "Get bananas", done: false },
        // { title: "Eat bananas", done: false },
        // { title: "Poo bananas", done: false }
      ]
    };
  },
  async mounted() {
   
  },
  methods: {
    addTask() {
      this.tasks.push({
        title: this.newTask,
        done: false
      });
      this.newTask = "";
    },
    deleteTask(index) {
      this.$q
        .dialog({
          title: "Confirm",
          message: "Really delete",
          cancel: true,
          persisten: true
        })
        .onOk(() => {
          this.tasks.splice(index, 1);
          this.$q.notify("Task delete");
        });
    },
     prompt () {
      this.$q.dialog({
        title: 'รายละเอียดบัญชี',
        message: 'ชื่อเจ้าของบัญชี',
        prompt: {
          model: '',
          type: 'text' // optional
        },
        cancel: true,
        persistent: true
      }).onOk(data => {
        // console.log('>>>> OK, received', data)
      }).onCancel(() => {
        // console.log('>>>> Cancel')
      }).onDismiss(() => {
        // console.log('I am triggered on both OK and Cancel')
      })
    }
  }

  
};



</script>


<style lang="scss">
.done {
  .q-item__label {
    text-decoration: line-through;
    color: #bbbbbb;
  }
}
.no-task {
  opacity: 0.5;
}



</style>