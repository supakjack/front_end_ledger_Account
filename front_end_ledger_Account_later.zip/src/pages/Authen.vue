<template>
  <q-page padding>
    <!-- content -->

    <br />
    <br />
    <br />
    <!-- start icon Piggy bank -->
    <div class="q-pa-md">
      <div class="q-col-gutter-md row items-start">
        <!-- start col 1-->
        <div class="col-4"></div>
        <!-- end col 1-->

        <!-- start col 2-->
        <div class="col-4" style="width:35%">
          <q-img src="https://image.flaticon.com/icons/svg/1660/1660899.svg" :ratio="1" />
        </div>
        <!-- end col 2-->

        <!-- start col 3 -->
        <div class="col-4"></div>
        <!-- end col 3 -->
      </div>
    </div>
    <!-- end icon Piggy bank -->

    <div style="font-size:20px ">
      <center>
        <font color="#6495ED">
          <b style="font-family:cursive;">Piggy Pocket</b>
        </font>
      </center>
    </div>

    <br />
    <!-- start button facebook -->
    <center>
      <div class="q-pa-md q-gutter-sm">
        <b>
          <q-btn
            class="glossy"
            style="font-family:cursive; font-size:16px;"
            rounded
            color="blue-14"
            label=" ผูกกับ Facebook "
            @click="loginFb()"
          />
          <!-- <q-btn
            class="glossy"
            style="font-family:cursive; font-size:16px;"
            rounded
            color="blue-14"
            label="ผูกกับ Facebook "
            @click="checkLoginState()"
          />-->
          <q-btn
            class="glossy"
            style="font-family:cursive; font-size:16px;"
            rounded
            color="blue-14"
            label="ยกเลิกการผูก Facebook "
            @click="logoutFb()"
          />
          <!-- <fb:login-button scope="public_profile,email" onlogin="checkLoginState();"></fb:login-button> -->
        </b>
        <!-- <q-img
          v-if="isLogin"
          :src="fbPicUrl"
          style="width: 150px"
          :ratio="1"
          basic
          spinner-color="white"
          class="rounded-borders"
        ></q-img> -->
        <!-- <img :src="fbPicUrl" /> -->
      </div>
    </center>
    <!-- end button facebook -->
  </q-page>
</template>

<script>
import FacebookServices from "./../services/FacebookServices";
// import { default as store } from "./../store/State";
export default {
  name: "Authen",
  async mounted() {
    //  this.fbPicUrl = await `http://graph.facebook.com/${store.state.userID}/picture?type=normal`;
    // console.log(await this.fbPicUrl);
    // this.isLogin = await store.state.userID != 0 ? store.state.userID : 0;
  },
  methods: {
    // rePicFb() {
    //   this.isLogin = store.state.userID != 0 ? store.state.userID : 0;
    // },
    // checkLoginState() {
    //   // this.fbPicUrl = `http://graph.facebook.com/${store.state.userID}/picture?type=normal`;
    //   // console.log(this.fbPicUrl);
    // },
    loginFb() {
      new FacebookServices().login()
    },
    logoutFb() {
      new FacebookServices().logout()
    }
  },
  data: function() {
    return {
      text: "",
      // fbPicUrl: "",
      // isLogin: false
    };
  }
};
</script>

<style lang="stylus" scoped></style>
