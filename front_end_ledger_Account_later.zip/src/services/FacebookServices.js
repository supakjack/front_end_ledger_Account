import { default as store } from "./../store/State";
export default class FacebookServices {
  login() {
    FB.login(function(response) {
      if (response.status === "connected") {
        if (response.status === "connected") {
          store.commit("setAccessToken", response.authResponse.accessToken);
          console.log(store.state.accessToken);
          store.commit("setUserID", response.authResponse.userID);
          console.log(store.state.userID);
          console.log(response);
          store.commit("setUserID", response.authResponse.userID);
          // this.fbPicUrl = `http://graph.facebook.com/${response.authResponse.userID}/picture?type=normal`;
          // console.log(this.fbPicUrl);
          // this.mounted();
          //
          //
        }
      } else {
        console.log("fail");

        // The person is not logged into your webpage or we are unable to tell.
      }
    });
  }
  logout() {
    FB.logout(function(response) {
      console.log(response);
    });
  }
}
