import AxiosServices from "./../services/AxiosServices";
import ChartServices from "./../services/ChartServices";
import SwalServices from "./../services/SwalServices";
import FacebookServices from "./../services/FacebookServices";

export default class ChartServices {
  constructor() {
    this.axiosServices = AxiosServices;
    this.chartServices = ChartServices;
    this.swalServices = SwalServices;
    this.facebookServices = FacebookServices;
  }
  makeAxios() {
    return this.axiosServices;
  }
  makeAxios() {
    return this.axiosServices;
  }
  makeAxios() {
    return this.axiosServices;
  }

}
